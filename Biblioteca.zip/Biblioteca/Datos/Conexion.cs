﻿using MySqlConnector;
using System;
using System.Data;

namespace Datos
{
    public class Conexion
    {
        private readonly string connectionString;

        public Conexion()
        {
            var builder = new MySqlConnectionStringBuilder
            {
                Server = "localhost",
                Database = "biblioteca",
                UserID = "root",
                Password = "",
                SslMode = MySqlSslMode.None
            };

            connectionString = builder.ConnectionString;
        }

        public MySqlConnection GetConnection()
        {
            return new MySqlConnection(connectionString);
        }

        public int EjecutarComando(string consulta, MySqlParameter[] parametros)
        {
            using var conn = GetConnection();
            conn.Open();
            using var cmd = new MySqlCommand(consulta, conn);
            cmd.Parameters.AddRange(parametros);
            return cmd.ExecuteNonQuery();
        }

        public MySqlDataReader? EjecutarConsulta(string consulta, MySqlParameter[]? parametros = null)
        {
            var conn = GetConnection();
            conn.Open();
            var cmd = new MySqlCommand(consulta, conn);

            if (parametros != null)
                cmd.Parameters.AddRange(parametros);

            return cmd.ExecuteReader(CommandBehavior.CloseConnection);
        }
    }
}