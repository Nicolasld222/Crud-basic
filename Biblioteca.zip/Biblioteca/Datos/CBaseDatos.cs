﻿using Datos.Entities;
using MySqlConnector;
using System;
using System.Collections.Generic;

namespace Datos
{
    public class CBaseDatos
    {
        private readonly Conexion conexion;

        public CBaseDatos()
        {
            conexion = new();
        }

        // Insertar libro
        public string GuardarLibro(string nombre, string serial, string autor)
        {
            try
            {
                string consulta = "INSERT INTO libro (nombre, serial, autor) VALUES (@nombre, @serial, @autor)";
                MySqlParameter[] parametros =
                [
                    new("@nombre", nombre),
                    new("@serial", serial),
                    new("@autor", autor)
                ];

                int filasAfectadas = conexion.EjecutarComando(consulta, parametros);
                return filasAfectadas > 0 ? "Libro guardado correctamente" : "No se pudo guardar el libro";
            }
            catch (Exception ex)
            {
                return "Error al guardar: " + ex.Message;
            }
        }

        // Actualizar libro
        public string ActualizarLibro(int id, string nombre, string serial, string autor)
        {
            try
            {
                string consulta = "UPDATE libro SET nombre = @nombre, serial = @serial, autor = @autor WHERE id = @id";
                MySqlParameter[] parametros =
                [
                    new("@id", id),
                    new("@nombre", nombre),
                    new("@serial", serial),
                    new("@autor", autor)
                ];

                int filasAfectadas = conexion.EjecutarComando(consulta, parametros);
                return filasAfectadas > 0 ? "Libro actualizado correctamente" : "No se pudo actualizar el libro";
            }
            catch (Exception ex)
            {
                return "Error al editar: " + ex.Message;
            }
        }

        // Eliminar libro
        public string EliminarLibro(int id)
        {
            try
            {
                string consulta = "DELETE FROM libro WHERE id = @id";
                MySqlParameter[] parametros = [new("@id", id)];

                int filasAfectadas = conexion.EjecutarComando(consulta, parametros);
                return filasAfectadas > 0 ? "Libro eliminado" : "No se pudo eliminar el libro";
            }
            catch (Exception ex)
            {
                return "Error al eliminar: " + ex.Message;
            }
        }

        // Listar libros
        public List<Clibro> ListaLibrosActual()
        {
            List<Clibro> listaLibros = [];

            try
            {
                string consulta = "SELECT id, nombre, serial, autor FROM libro ORDER BY id";
                using MySqlDataReader? reader = conexion.EjecutarConsulta(consulta);

                if (reader != null)
                {
                    while (reader.Read())
                    {
                        Clibro libro = new()
                        {
                            ID = reader.GetInt32("id"),
                            Nombre = reader.GetString("nombre"),
                            Serial = reader.GetString("serial"),
                            Autor = reader.GetString("autor")
                        };

                        listaLibros.Add(libro);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error al listar libros: " + ex.Message);
            }

            return listaLibros;
        }
    }
}