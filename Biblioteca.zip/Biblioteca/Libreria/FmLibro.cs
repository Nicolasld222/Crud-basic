﻿using Logica;
using System;
using System.Windows.Forms;

namespace Libreria
{
    public partial class FmLibro : Form
    {
        private readonly LibrosController controller;
        private int libroSeleccionadoId = 0;

        public FmLibro()
        {
            InitializeComponent();
            controller = new();
        }

        private void FmLibro_Load(object sender, EventArgs e)
        {
            CargarLibros();
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox3.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Todos los campos son obligatorios");
                return;
            }

            string nombre = textBox3.Text;
            string serial = textBox2.Text;
            string autor = textBox1.Text;

            string respuesta = controller.GuardarDatos(nombre, serial, autor);
            MessageBox.Show(respuesta);

            LimpiarCampos();
            CargarLibros();
        }

        private void BtnEditar_Click(object sender, EventArgs e)
        {
            if (libroSeleccionadoId == 0)
            {
                MessageBox.Show("Primero busque un libro para editar");
                return;
            }

            if (string.IsNullOrWhiteSpace(textBox3.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("Todos los campos son obligatorios");
                return;
            }

            string nombre = textBox3.Text;
            string serial = textBox2.Text;
            string autor = textBox1.Text;

            string respuesta = controller.ActualizarDatos(libroSeleccionadoId, nombre, serial, autor);
            MessageBox.Show(respuesta);

            LimpiarCampos();
            CargarLibros();
        }

        private void BtnEliminar_Click(object sender, EventArgs e)
        {
            if (libroSeleccionadoId == 0)
            {
                MessageBox.Show("Primero busque un libro para eliminar");
                return;
            }

            DialogResult resultado = MessageBox.Show(
                "¿Está seguro de eliminar este libro?",
                "Confirmar eliminación",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );

            if (resultado == DialogResult.Yes)
            {
                string respuesta = controller.EliminarDatos(libroSeleccionadoId);
                MessageBox.Show(respuesta);

                LimpiarCampos();
                CargarLibros();
            }
        }

        private void BtnBuscar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Ingrese el serial para buscar");
                return;
            }

            var lista = controller.ListaLibros();
            var libro = lista.Find(l => l.Serial == textBox2.Text);

            if (libro != null)
            {
                textBox3.Text = libro.Nombre;
                textBox1.Text = libro.Autor;
                libroSeleccionadoId = libro.ID;

                MessageBox.Show("Libro encontrado");
            }
            else
            {
                MessageBox.Show("No se encontró el libro con ese serial");
                LimpiarCampos();
            }
        }

        private void LimpiarCampos()
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            libroSeleccionadoId = 0;
        }

        private void CargarLibros()
        {
            // Si tienes DataGridView descomenta: dgvLibros.DataSource = controller.ListaLibros();
            _ = controller.ListaLibros(); // Mantiene conexión activa, descarta resultado
        }
    }
}