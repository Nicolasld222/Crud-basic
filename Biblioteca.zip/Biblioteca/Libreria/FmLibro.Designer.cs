﻿namespace Libreria
{
    partial class FmLibro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer? components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnGuardar = new Button();
            btnEditar = new Button();
            btnEliminar = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox3 = new TextBox();
            btnBuscar = new Button();
            lblNombre = new Label();
            lblSerial = new Label();
            lblAutor = new Label();
            label1 = new Label();
            SuspendLayout();
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(151, 337);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(68, 41);
            btnGuardar.TabIndex = 0;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += BtnGuardar_Click;
            // 
            // btnEditar
            // 
            btnEditar.Location = new Point(225, 337);
            btnEditar.Name = "btnEditar";
            btnEditar.Size = new Size(57, 41);
            btnEditar.TabIndex = 1;
            btnEditar.Text = "Editar";
            btnEditar.UseVisualStyleBackColor = true;
            btnEditar.Click += BtnEditar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Location = new Point(288, 337);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(62, 41);
            btnEliminar.TabIndex = 2;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += BtnEliminar_Click;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(151, 293);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(267, 23);
            textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(151, 214);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(267, 23);
            textBox2.TabIndex = 4;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(151, 130);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(267, 23);
            textBox3.TabIndex = 5;
            // 
            // btnBuscar
            // 
            btnBuscar.Location = new Point(356, 337);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new Size(62, 41);
            btnBuscar.TabIndex = 6;
            btnBuscar.Text = "Buscar";
            btnBuscar.UseVisualStyleBackColor = true;
            btnBuscar.Click += BtnBuscar_Click;
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Location = new Point(151, 99);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(78, 15);
            lblNombre.TabIndex = 7;
            lblNombre.Text = "Nombre libro";
            // 
            // lblSerial
            // 
            lblSerial.AutoSize = true;
            lblSerial.Location = new Point(151, 185);
            lblSerial.Name = "lblSerial";
            lblSerial.Size = new Size(35, 15);
            lblSerial.TabIndex = 8;
            lblSerial.Text = "Serial";
            // 
            // lblAutor
            // 
            lblAutor.AutoSize = true;
            lblAutor.Location = new Point(151, 263);
            lblAutor.Name = "lblAutor";
            lblAutor.Size = new Size(37, 15);
            lblAutor.TabIndex = 9;
            lblAutor.Text = "Autor";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 20F);
            label1.Location = new Point(173, 34);
            label1.Name = "label1";
            label1.Size = new Size(213, 37);
            label1.TabIndex = 10;
            label1.Text = "Pagina de Libros";
            // 
            // FmLibro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(610, 450);
            Controls.Add(label1);
            Controls.Add(lblAutor);
            Controls.Add(lblSerial);
            Controls.Add(lblNombre);
            Controls.Add(btnBuscar);
            Controls.Add(textBox3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(btnEliminar);
            Controls.Add(btnEditar);
            Controls.Add(btnGuardar);
            Name = "FmLibro";
            Text = "FmLibro";
            Load += FmLibro_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnGuardar;
        private Button btnEditar;
        private Button btnEliminar;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private Button btnBuscar;
        private Label lblNombre;
        private Label lblSerial;
        private Label lblAutor;
        private Label label1;
    }
}