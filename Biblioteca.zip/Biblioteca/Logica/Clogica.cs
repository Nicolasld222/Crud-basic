﻿using Datos;
using Datos.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Logica
{
    public class LibrosController
    {
        private readonly CBaseDatos baseDatos;

        public LibrosController()
        {
            baseDatos = new();
        }

        // Guardar libro
        public string GuardarDatos(string nombre, string serial, string autor)
        {
            return baseDatos.GuardarLibro(nombre, serial, autor);
        }

        // Listar todos los libros
        public List<Clibro> ListaLibros()
        {
            return baseDatos.ListaLibrosActual();
        }

        // Actualizar libro
        public string ActualizarDatos(int id, string nombre, string serial, string autor)
        {
            return baseDatos.ActualizarLibro(id, nombre, serial, autor);
        }

        // Eliminar libro
        public string EliminarDatos(int id)
        {
            return baseDatos.EliminarLibro(id);
        }

        // Buscar libros por nombre
        public List<Clibro> BuscarLibros(string nombre)
        {
            List<Clibro> lista = baseDatos.ListaLibrosActual();
            return lista.FindAll(l => l.Nombre?.Contains(nombre, StringComparison.OrdinalIgnoreCase) == true);
        }
    }
}